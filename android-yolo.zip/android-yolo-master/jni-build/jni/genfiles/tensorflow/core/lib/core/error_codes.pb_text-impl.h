// GENERATED FILE - DO NOT MODIFY
#ifndef tensorflow_core_lib_core_error_codes_proto_IMPL_H_
#define tensorflow_core_lib_core_error_codes_proto_IMPL_H_

#include "tensorflow/core/lib/core/error_codes.pb.h"
#include "tensorflow/core/lib/core/error_codes.pb_text.h"
#include "tensorflow/core/lib/strings/proto_text_util.h"
#include "tensorflow/core/lib/strings/scanner.h"

namespace tensorflow {
namespace error {

namespace internal {

}  // namespace internal

}  // namespace error
}  // namespace tensorflow

#endif  // tensorflow_core_lib_core_error_codes_proto_IMPL_H_
