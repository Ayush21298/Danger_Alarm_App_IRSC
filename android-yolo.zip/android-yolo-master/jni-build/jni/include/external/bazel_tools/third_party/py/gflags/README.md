[gflags](https://python-gflags.googlecode.com)
--------

* Version: 2.0
* License: New BSD License
* From: [https://python-gflags.googlecode.com/files/python-gflags-2.0.tar.gz](https://python-gflags.googlecode.com/files/python-gflags-2.0.tar.gz)
